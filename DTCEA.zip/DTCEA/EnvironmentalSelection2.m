function Population = EnvironmentalSelection2(Population, Offspring, zmin, Ns, Add1, Add2, epsilon_gen)
% Add2 = 1 --- environmental selection of SPEA2
% Add2 = 2 --- environmental selection of NSGA-II
% Add2 = 3 --- environmental selection of modified NSGA-III
%% Dominance relation calculation
Population = [Population, Offspring];


if Add1 == 1 % PD
    NonDominated = DominationCal(Population, 0);

    Population = Population(NonDominated);
    PopObj = Population.objs;
    [P, M] = size(PopObj);
    if P <= Ns
        Population = Population([1:P, unidrnd(P,[1, Ns - P])]);
    elseif Add2 == 1
        zmax   = max(PopObj, [], 1);
        PopObj = (PopObj - zmin) ./ (zmax - zmin);
        Del    = Truncation(PopObj, P - Ns);
        remained_solution1 = 1: P;
        remained_solution1(Del) = [];
        Population = Population(remained_solution1);
    elseif Add2 == 2
        zmax     = max(PopObj, [], 1);
        PopObj   = (PopObj - zmin) ./ (zmax - zmin);
        CrowdDis = CrowdingDistance(PopObj);
        [~,Rank] = sort(CrowdDis,'descend');
        Population = Population(Rank(1:Ns));
    elseif Add2 == 3
        [W, Ns]  = UniformPoint(Ns, M);
        zmax     = max(PopObj, [], 1);
        PopObj   = (PopObj - zmin) ./ (zmax - zmin);
        Distance = sqrt(sum(PopObj.^2, 2));
        Angle_Pop_to_W = sin(acos(1 - pdist2(W, PopObj, 'cosine')));
        S  = Population;
        Population = [];
        for i = 1 : Ns
            Fitness   = Distance' .* Angle_Pop_to_W(i,:);
            [~,index] = min(Fitness);
            Population = [Population,S(index)];
        end
    end
elseif Add1 == 2 % Epsilon-Constraint-Pareto dominance1
    NonDominated = DominationCal_epsilon(Population, 1, epsilon_gen);
    Population = Population(NonDominated);
    PopObj = Population.objs;
    [P, ~] = size(PopObj);
    if P <= Ns
        Population = Population([1:P, unidrnd(P,[1, Ns - P])]);
    else
        PopCon = Population.cons;
        Cons   = sum(max(0,PopCon),2);
        FA1    = Population(Cons <= 0);
        PopObj1 = FA1.objs;
        FA2    = Population(Cons > 0);
        PopObj2 = FA2.objs;
        N1 = ceil(size(PopObj1,1)/P*Ns);
        N2 = Ns-N1;
        if Add2 == 1
            [P1, ~] = size(PopObj1);
            zmin1   = min(PopObj1, [], 1) - 1e-6;
            zmax1   = max(PopObj1, [], 1);
            PopObj1 = (PopObj1 - zmin1) ./ (zmax1 - zmin1);
            Del1    = Truncation(PopObj1, P1 - N1);
            remained_solution1 = 1 : P1;
            remained_solution1(Del1) = [];
            [P2, ~] = size(PopObj2);
            zmin2   = min(PopObj2, [], 1) - 1e-6;
            zmax2   = max(PopObj2, [], 1);
            PopObj2 = (PopObj2 - zmin2) ./ (zmax2 - zmin2);
            Del2    = Truncation(PopObj2, P2 - N2);
            remained_solution2 = 1 : P2;
            remained_solution2(Del2) = [];
            Population = [FA1(remained_solution1) FA2(remained_solution2)];
        elseif Add2 == 2
            zmin1   = min(PopObj1, [], 1) - 1e-6;
            zmax1   = max(PopObj1, [], 1);
            PopObj1 = (PopObj1 - zmin1) ./ (zmax1 - zmin1);
            CrowdDis1 = CrowdingDistance(PopObj1);
            [~,Rank1] = sort(CrowdDis1,'descend');
            zmin2   = min(PopObj2, [], 1) - 1e-6;
            zmax2   = max(PopObj2, [], 1);
            PopObj2 = (PopObj2 - zmin2) ./ (zmax2 - zmin2);
            CrowdDis2 = CrowdingDistance(PopObj2);
            [~,Rank2] = sort(CrowdDis2,'descend');
            Population = [FA1(Rank1(1:N1)) FA2(Rank2(1:N2))];
        end
    end
elseif Add1 == 3 % Epsilon-Constraint-Pareto dominance2
    NonDominated = DominationCal_epsilon(Population, 2, epsilon_gen);
    Population = Population(NonDominated);
    PopObj = Population.objs;
    [P, ~] = size(PopObj);
    if P <= Ns
        Population = Population([1:P, unidrnd(P,[1, Ns - P])]);
    else
        PopCon = Population.cons;
        Cons   = sum(max(0,PopCon),2);
        FA1    = Population(Cons <= epsilon_gen);
        PopObj1 = FA1.objs;
        FA2    = Population(Cons > epsilon_gen);
        PopObj2 = FA2.objs;
        N1 = ceil(size(PopObj1,1)/P*Ns);
        N2 = Ns-N1;
        if Add2 == 1
            [P1, ~] = size(PopObj1);
            zmin1   = min(PopObj1, [], 1) - 1e-6;
            zmax1   = max(PopObj1, [], 1);
            PopObj1 = (PopObj1 - zmin1) ./ (zmax1 - zmin1);
            Del1    = Truncation(PopObj1, P1 - N1);
            remained_solution1 = 1 : P1;
            remained_solution1(Del1) = [];
            [P2, ~] = size(PopObj2);
            zmin2   = min(PopObj2, [], 1) - 1e-6;
            zmax2   = max(PopObj2, [], 1);
            PopObj2 = (PopObj2 - zmin2) ./ (zmax2 - zmin2);
            Del2    = Truncation(PopObj2, P2 - N2);
            remained_solution2 = 1 : P2;
            remained_solution2(Del2) = [];
            Population = [FA1(remained_solution1) FA2(remained_solution2)];
        elseif Add2 == 2
            zmin1   = min(PopObj1, [], 1) - 1e-6;
            zmax1   = max(PopObj1, [], 1);
            PopObj1 = (PopObj1 - zmin1) ./ (zmax1 - zmin1);
            CrowdDis1 = CrowdingDistance(PopObj1);
            [~,Rank1] = sort(CrowdDis1,'descend');
            zmin2   = min(PopObj2, [], 1) - 1e-6;
            zmax2   = max(PopObj2, [], 1);
            PopObj2 = (PopObj2 - zmin2) ./ (zmax2 - zmin2);
            CrowdDis2 = CrowdingDistance(PopObj2);
            [~,Rank2] = sort(CrowdDis2,'descend');
            Population = [FA1(Rank1(1:N1)) FA2(Rank2(1:N2))];
        end
    end
elseif Add1 == 4
    NonDominated = DominationCal_epsilon(Population, 3, epsilon_gen);
    Population = Population(NonDominated);
    PopObj = Population.objs;
    [P, M] = size(PopObj);
    if P <= Ns
        Population = Population([1:P, unidrnd(P,[1, Ns - P])]);
    elseif Add2 == 1
        zmax   = max(PopObj, [], 1);
        PopObj = (PopObj - zmin) ./ (zmax - zmin);
        Del    = Truncation(PopObj, P - Ns);
        remained_solution1 = 1: P;
        remained_solution1(Del) = [];
        Population = Population(remained_solution1);
    elseif Add2 == 2
        zmax     = max(PopObj, [], 1);
        PopObj   = (PopObj - zmin) ./ (zmax - zmin);
        CrowdDis = CrowdingDistance(PopObj);
        [~,Rank] = sort(CrowdDis,'descend');
        Population = Population(Rank(1:Ns));
    elseif Add2 == 3
        [W, Ns]  = UniformPoint(Ns, M);
        zmax     = max(PopObj, [], 1);
        PopObj   = (PopObj - zmin) ./ (zmax - zmin);
        Distance = sqrt(sum(PopObj.^2, 2));
        Angle_Pop_to_W = sin(acos(1 - pdist2(W, PopObj, 'cosine')));
        S  = Population;
        Population = [];
        for i = 1 : Ns
            Fitness   = Distance' .* Angle_Pop_to_W(i,:);
            [~,index] = min(Fitness);
            Population = [Population,S(index)];
        end
    end
end

end

function Del = Truncation(PopObj,K)
% Select part of the solutions by truncation

%% Truncation
Distance = pdist2(PopObj,PopObj);
Distance(logical(eye(length(Distance)))) = inf;
Del = false(1,size(PopObj,1));
while sum(Del) < K
    Remain   = find(~Del);
    Temp     = sort(Distance(Remain,Remain),2);
    [~,Rank] = sortrows(Temp);
    Del(Remain(Rank(1))) = true;
end
end