 function NonDominated = DominationCal_epsilon(Population, Add, epsilon_gen)
% The dominance relation calculation of
% add = 1 --- Dynamic constraint-Pareto dominance
% add = 2 --- Dynamic CDP

PopObj = Population.objs;
PopObj = roundn(PopObj, -10);
[N, M] = size(PopObj);
PopCon = Population.cons;
Cons = sum(max(0, PopCon), 2);
Dominated = false(1, N);
for i = 1 : N-1
    err = PopObj(i, :) - PopObj;
    eq = zeros(N, 1);
    max_err = max(err, [], 2);
    min_err = min(err, [], 2);
    for j = i + 1 : N
        for k = 1 : M
            if err(j, k) ~= 0
                break;
            end
            if k == M
                eq(j) = 1;
            end
        end
        if Add == 1  % Epsilon-Constraint-Pareto dominance1
            if Cons(i) <= epsilon_gen && Cons(j) <= epsilon_gen
                % Both have constraint violation less than epsilon_gen, use Constraint-Pareto dominance
                if eq(j) == 1
                    if Cons(i) <= Cons(j)
                        Dominated(j) = true;
                    else
                        Dominated(i) = true;
                    end
                elseif min_err(j) >= 0
                    if  Cons(j) <= 0 || Cons(j) <= Cons(i)
                        Dominated(i) = true;
                    end
                elseif max_err(j) <= 0
                    if  Cons(i) <= 0 || Cons(i) <= Cons(j)
                        Dominated(j) = true;
                    end
                end
            elseif Cons(i) <= epsilon_gen && Cons(j) > epsilon_gen
                Dominated(j) = true;
            elseif Cons(j) <= epsilon_gen && Cons(i) > epsilon_gen
                Dominated(i) = true;
            elseif Cons(i) > epsilon_gen && Cons(j) > epsilon_gen
                if eq(j) == 1
                    if Cons(i) <= Cons(j)
                        Dominated(j) = true;
                    else
                        Dominated(i) = true;
                    end
                elseif min_err(j) >= 0 
                    if Cons(j) <= Cons(i)
                        Dominated(i) = true;
                    end
                elseif max_err(j) <= 0
                    if Cons(i) <= Cons(j)
                        Dominated(j) = true;
                    end
                end
            end
        elseif Add == 2
            if eq(j) == 1
                if Cons(i) <= Cons(j)
                    Dominated(j) = true;
                else
                    Dominated(i) = true;
                end
            elseif min_err(j) >= 0
                if Cons(j) <= epsilon_gen || Cons(j) <= Cons(i)
                    Dominated(i) = true;
                end
            elseif max_err(j) <= 0
                if Cons(i) <= epsilon_gen || Cons(i) <= Cons(j)
                    Dominated(j) = true;
                end
            end

        elseif Add == 3  % Epsilon-CDP dominance
            if Cons(i) <= epsilon_gen && Cons(j) > epsilon_gen
                Dominated(j) = true;
            elseif Cons(j) <= epsilon_gen && Cons(i) > epsilon_gen
                Dominated(i) = true;
            elseif Cons(i) <= epsilon_gen && Cons(j) <= epsilon_gen
                % Both feasible, use Pareto dominance
                if eq(j) == 1
                    Dominated(j) = true;
                elseif min_err(j) >= 0
                    Dominated(i) = true;
                elseif max_err(j) <= 0
                    Dominated(j) = true;
                end
            elseif Cons(i) > epsilon_gen && Cons(j) > epsilon_gen
                % Both infeasible, compare constraint violation
                if Cons(i) < Cons(j)
                    Dominated(j) = true;
                elseif Cons(j) < Cons(i)
                    Dominated(i) = true;
                end
            end
        end
    end
end
NonDominated = ~Dominated;
end
