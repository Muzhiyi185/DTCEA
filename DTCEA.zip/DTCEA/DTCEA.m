classdef DTCEA < ALGORITHM
    % e1 --- 1 --- Type of environmental selection for P1(1. SPEA2 2. NSGA-II 3. modified NSGA-III)
    % e2 --- 1 --- Type of environmental selection for P2(1. SPEA2 2. NSGA-II 3. modified NSGA-III)

    methods
        function main(Algorithm,Problem)
            %% Parameter setting
            [last_gen,beta,e1,e2] = Algorithm.ParameterSet(40,0.05,2,2);
            Ns = floor(Problem.N/2);
            N1 = floor(Problem.N/3);

            %% Generate random population
            Population = Problem.Initialization();
            P1 = Population;      
            P2 = P1(randperm(Problem.N,N1));
            P3 = P1(randperm(Problem.N,N1));
            Offspring = Population;
            max_change = 1;
            zmin      = min(Population.objs,[],1) - 1e-6;
            ideal_points = zeros(ceil(Problem.maxFE/Problem.N),Problem.M);
            nadir_points = zeros(ceil(Problem.maxFE/Problem.N),Problem.M);
            epsilon0     = max(sum(max(0,Population.cons),2));
            if epsilon0 == 0
                epsilon0 = 1;
            end
            gen = 1;
        
            %% Optimization
            while Algorithm.NotTerminated(P1)
                ideal_points(gen,:) = min(P2.objs,[],1);
                nadir_points(gen,:) = max(P2.objs,[],1);
                cp  = (-log(epsilon0)-6)/log(1-0.5);
                epsilon_gen = epsilon0*(1-gen/(ceil(Problem.maxFE/Problem.N)))^cp;
                zmin = min(zmin, min(Offspring.objs, [], 1) - 1e-6);
                if gen > last_gen
                    max_change = calc_maxchange(ideal_points,nadir_points,gen,last_gen);
                end
                if max_change > beta
                    P1  = EnvironmentalSelection1(P1, Offspring, Problem.N, 3, e1, epsilon_gen);
                    P2 = EnvironmentalSelection2(P2, Offspring, zmin, N1, 1, e2, epsilon_gen);
                    P3 = EnvironmentalSelection3(P3, Offspring, zmin, N1, 2, epsilon_gen);
                    Pop1 = P2;
                    Pop2 = P3;
                    Pop3 = P1(unidrnd(length(P1), [1, Problem.N-2*N1]));
                    MatingPool_Pop1_1 = randperm(length(Pop1));
                    MatingPool_Pop1_2 = randperm(length(Pop1));
                    MatingPool_Pop2_1 = randperm(length(Pop2));
                    MatingPool_Pop2_2 = randperm(length(Pop2));
                    MatingPool_Pop3_1 = randperm(length(Pop3));
                    MatingPool_Pop3_2 = randperm(length(Pop3));
                    if rand() < 0.5
                        Offspring1 = OperatorDE(Problem, Pop1, Pop1(MatingPool_Pop1_1), Pop1(MatingPool_Pop1_2),{1,0.5,1,1});
                        Offspring2 = OperatorDE(Problem, Pop2, Pop2(MatingPool_Pop2_1), Pop2(MatingPool_Pop2_2),{1,0.5,1,1});
                        Offspring3 = OperatorDE(Problem, Pop3, Pop3(MatingPool_Pop3_1), Pop3(MatingPool_Pop3_2),{1,0.5,1,1});
                    else
                        Offspring1 = OperatorGA(Problem, Pop1(MatingPool_Pop1_1), {1,20,1,1});
                        Offspring2 = OperatorGA(Problem, Pop2(MatingPool_Pop2_1), {1,20,1,1});
                        Offspring3 = OperatorGA(Problem, Pop3(MatingPool_Pop3_1), {1,20,1,1});
                    end
                    Offspring = [Offspring1, Offspring2, Offspring3];
                else
                    P1 = EnvironmentalSelection1(P1, Offspring, Problem.N, 3, e1, epsilon_gen);
                    P2 = EnvironmentalSelection2(P2, Offspring, zmin, Ns, 1, e2, epsilon_gen);
                    P3 = EnvironmentalSelection3(P3, Offspring, zmin, Ns, 2, epsilon_gen);
                    Pop2 = P3;
                    Pop3 = P1(unidrnd(length(P1), [1, Ns]));
                    MatingPool_Pop2_1 = randperm(length(Pop2));
                    MatingPool_Pop2_2 = randperm(length(Pop2));
                    MatingPool_Pop3_1 = randperm(length(Pop3));
                    MatingPool_Pop3_2 = randperm(length(Pop3));
                    if rand() < 0.5
                        Offspring2 = OperatorDE(Problem, Pop2, Pop2(MatingPool_Pop2_1), Pop2(MatingPool_Pop2_2),{1,0.5,1,1});
                        Offspring3 = OperatorDE(Problem, Pop3, Pop3(MatingPool_Pop3_1), Pop3(MatingPool_Pop3_2),{1,0.5,1,1});
                    else
                        Offspring2 = OperatorGA(Problem, Pop2(MatingPool_Pop2_1), {1,20,1,1});
                        Offspring3 = OperatorGA(Problem, Pop3(MatingPool_Pop3_1), {1,20,1,1});
                    end
                    Offspring = [Offspring2, Offspring3];
                end
                gen = gen + 1;
            end
        end
    end
end
function max_change = calc_maxchange(ideal_points,nadir_points,gen,last_gen)
% Calculate the maximum rate of change of objectives
delta_value = 1e-6 * ones(1,size(ideal_points,2));
rz  = abs((ideal_points(gen,:) - ideal_points(gen - last_gen + 1,:)) ./ max(ideal_points(gen - last_gen + 1,:),delta_value));
nrz = abs((nadir_points(gen,:) - nadir_points(gen - last_gen + 1,:)) ./ max(nadir_points(gen - last_gen + 1,:),delta_value));
max_change = max([rz, nrz]);
end