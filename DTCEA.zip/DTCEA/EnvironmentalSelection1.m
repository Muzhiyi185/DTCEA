function FEA = EnvironmentalSelection1(FEA, Offspring, N, Add1, Add2, epsilon_gen)
% Add2 = 1 --- environmental selection of SPEA2
% Add2 = 2 --- environmental selection of NSGA-II
% Add2 = 3 --- environmental selection of modified NSGA-III
%% Dominance relation calculation
FEA = [FEA, Offspring];
if Add1 == 1 %CPD
    NonDominated = DominationCal(FEA, 1);
elseif Add1 == 2 %CDP
    NonDominated = DominationCal(FEA, 2);
elseif Add1 == 3 % Epsilon-Constraint-Pareto dominance
    NonDominated = DominationCal_epsilon(FEA, 1, epsilon_gen);
end


FEA = FEA(NonDominated);
PopObj = FEA.objs;
[P, M] = size(PopObj);
if P <= N
    FEA = FEA([1:P, unidrnd(P,[1, N - P])]);
else
    PopCon = FEA.cons;
    Cons   = sum(max(0,PopCon),2);
    if sum(Cons <= 0) <= N
        [~, index] = sort(Cons);
        remained_solution = index(1: N);
        FEA = FEA(remained_solution);
        %% Enviornmental selection
    elseif Add2 == 1
        FEA    = FEA(Cons <= 0);
        PopObj = FEA.objs;
        [P, ~] = size(PopObj);
        zmin   = min(PopObj, [], 1) - 1e-6;
        zmax   = max(PopObj, [], 1);
        PopObj = (PopObj - zmin) ./ (zmax - zmin);
        Del    = Truncation(PopObj, P - N);
        remained_solution = 1 : P;
        remained_solution(Del) = [];
        FEA = FEA(remained_solution);
    elseif Add2 == 2
        FEA      = FEA(Cons <= 0);
        PopObj   = FEA.objs;
        zmin     = min(PopObj, [], 1) - 1e-6;
        zmax     = max(PopObj, [], 1);
        PopObj   = (PopObj - zmin) ./ (zmax - zmin);
        CrowdDis = CrowdingDistance(PopObj);
        [~,Rank] = sort(CrowdDis,'descend');
        FEA = FEA(Rank(1:N));
    elseif Add2 == 3
        FEA      = FEA(Cons <= 0);
        PopObj   = FEA.objs;
        [W, N]   = UniformPoint(N, M);
        zmin     = min(PopObj, [], 1) - 1e-6;
        zmax     = max(PopObj, [], 1);
        PopObj   = (PopObj - zmin) ./ (zmax - zmin);
        Distance = sqrt(sum(PopObj.^2, 2));
        Angle_Pop_to_W = sin(acos(1 - pdist2(W, PopObj, 'cosine')));
        S   = FEA;
        FEA = [];
        for i = 1 : N
            Fitness   = Distance' .* Angle_Pop_to_W(i,:);
            [~,index] = min(Fitness);
            FEA = [FEA,S(index)];
        end
    end
end
end

function Del = Truncation(PopObj,K)
% Select part of the solutions by truncation

%% Truncation
Distance = pdist2(PopObj,PopObj);
Distance(logical(eye(length(Distance)))) = inf;
Del = false(1,size(PopObj,1));
while sum(Del) < K
    Remain   = find(~Del);
    Temp     = sort(Distance(Remain,Remain),2);
    [~,Rank] = sortrows(Temp);
    Del(Remain(Rank(1))) = true;
end
end